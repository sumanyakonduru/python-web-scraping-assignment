import re
import unicodedata


def normalize(value):
    """Lowercase, strip accents/punctuation noise, collapse whitespace."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"[^\w\s]", "", text.lower())
    return re.sub(r"\s+", " ", text).strip()


def dedup_key(record):
    """
    Duplicate key = source + normalized title/quote + normalized author.
    URL is deliberately NOT part of the key: the same item can appear under a
    different URL (e.g. quotes share a page URL; books may be re-listed), so
    including it would hide real duplicates.
    """
    return (
        normalize(record.get("source")),
        normalize(record.get("name_or_title")),
        normalize(record.get("author")),
    )


def deduplicate_records(records):
    seen = set()
    unique, duplicates = [], []
    for record in records:
        key = dedup_key(record)
        if key in seen:
            duplicates.append(record)
        else:
            seen.add(key)
            unique.append(record)
    return unique, duplicates
