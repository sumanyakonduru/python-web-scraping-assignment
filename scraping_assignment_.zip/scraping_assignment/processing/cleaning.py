import re
from urllib.parse import urlparse


def clean_text(value):
    if value is None:
        return None
    value = re.sub(r"\s+", " ", str(value)).strip()
    return value if value else None


def clean_price(value):
    if value is None:
        return None
    match = re.search(r"\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else None


def clean_rating(value):
    if value is None:
        return None
    try:
        value = int(value)
        return value if 1 <= value <= 5 else None
    except (TypeError, ValueError):
        return None


def clean_url(value):
    value = clean_text(value)
    if not value:
        return None
    try:
        parsed = urlparse(value)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            return value
    except ValueError:
        pass
    return None


def clean_record(record):
    cleaned = dict(record)

    text_fields = [
        "source", "name_or_title", "category", "author",
        "tags", "description", "availability"
    ]
    for field in text_fields:
        cleaned[field] = clean_text(cleaned.get(field))

    cleaned["source_url"] = clean_url(cleaned.get("source_url"))
    cleaned["price"] = clean_price(cleaned.get("price"))
    cleaned["rating"] = clean_rating(cleaned.get("rating"))

    return cleaned


def clean_records(records):
    return [clean_record(record) for record in records]
