from urllib.parse import urlparse

EXPECTED_SOURCES = {"Books to Scrape", "Quotes to Scrape"}


def valid_url(value):
    if not value:
        return False
    try:
        parsed = urlparse(value)
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except ValueError:
        return False


def validate_record(record):
    if record.get("source") not in EXPECTED_SOURCES:
        return False, "invalid_source"

    if not record.get("source_url") or not valid_url(record["source_url"]):
        return False, "invalid_url"

    if not record.get("name_or_title"):
        return False, "missing_name_or_title"

    price = record.get("price")
    if price is not None and (not isinstance(price, (int, float)) or price < 0):
        return False, "invalid_price"

    rating = record.get("rating")
    if rating is not None and (not isinstance(rating, int) or not 1 <= rating <= 5):
        return False, "invalid_rating"

    return True, None


def validate_records(records):
    valid = []
    rejected = []

    for record in records:
        ok, reason = validate_record(record)
        if ok:
            valid.append(record)
        else:
            rejected.append({"record": record, "reason": reason})

    return valid, rejected
