import json
import logging
import os
import time
from collections import Counter

import pandas as pd

from scrapers.books_scraper import scrape_books
from scrapers.quotes_scraper import scrape_quotes
from processing.cleaning import clean_records
from processing.validation import validate_records
from processing.deduplication import deduplicate_records


OUTPUT_DIR = "output"
LOG_DIR = "logs"


def setup_logging():
    os.makedirs(LOG_DIR, exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(
                os.path.join(LOG_DIR, "scraper.log"),
                encoding="utf-8"
            ),
            logging.StreamHandler(),
        ],
    )


def main():
    start = time.perf_counter()
    setup_logging()
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    logging.info("Pipeline started")

    books = scrape_books()
    quotes = scrape_quotes()

    collected = books + quotes

    logging.info("Total collected: %d", len(collected))

    cleaned = clean_records(collected)
    valid, rejected = validate_records(cleaned)
    unique, duplicates = deduplicate_records(valid)

    columns = [
        "source", "source_url", "name_or_title", "category",
        "price", "rating", "author", "tags", "description",
        "availability", "scraped_at"
    ]

    dataframe = pd.DataFrame(unique, columns=columns)
    dataframe["rating"] = dataframe["rating"].astype("Int64")  # keep 3, not 3.0

    csv_path = os.path.join(OUTPUT_DIR, "final_dataset.csv")
    dataframe.to_csv(csv_path, index=False, encoding="utf-8")

    elapsed = time.perf_counter() - start

    def per_source(rows):
        return dict(Counter(r.get("source") for r in rows))

    pd.DataFrame(duplicates).to_csv(
        os.path.join(OUTPUT_DIR, "duplicates_removed.csv"), index=False, encoding="utf-8")
    pd.DataFrame([{**r["record"], "reason": r["reason"]} for r in rejected]).to_csv(
        os.path.join(OUTPUT_DIR, "rejected_records.csv"), index=False, encoding="utf-8")

    summary = {
        "books_records_collected": len(books),
        "quotes_records_collected": len(quotes),
        "total_records_collected": len(collected),
        "records_after_cleaning": len(cleaned),
        "records_rejected_during_validation": len(rejected),
        "rejection_reasons": dict(Counter(r["reason"] for r in rejected)),
        "duplicate_records_detected": len(duplicates),
        "duplicate_records_removed": len(duplicates),
        "final_records_per_source": per_source(unique),
        "final_record_count": len(unique),
        "execution_time_seconds": round(elapsed, 2),
        "output_file": csv_path,
    }

    summary_path = os.path.join(OUTPUT_DIR, "summary_report.json")
    with open(summary_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=4)

    logging.info("Pipeline finished")
    logging.info("Final records: %d", len(unique))

    print("\nSUCCESS")
    print(f"Final records: {len(unique)}")
    print(f"CSV: {csv_path}")
    print(f"Summary: {summary_path}")


if __name__ == "__main__":
    main()
