# AI Usage

## Tools Used
- ChatGPT / Claude (edit to the tools you actually used)

## What Each Tool Was Used For
- Understanding the assignment and designing the project structure
- Drafting initial scraper code (Requests + BeautifulSoup, pagination via the "next" link)
- Designing the schema, cleaning, validation and deduplication functions
- Reviewing the final code and fixing issues
- Writing README and unit tests

## Representative Prompts
1. "Summarize the Python web scraping assignment and explain what needs to be built."
2. "Create a Python Requests and BeautifulSoup scraper with pagination."
3. "Design a standardized schema for Books to Scrape and Quotes to Scrape."
4. "Add validation, deduplication, logging, and error handling."
5. "Review my project for mistakes against the assignment requirements."

## AI-Assisted Parts
Scrapers, cleaning/validation/deduplication modules, main.py pipeline, tests, documentation.

## Important Changes After Reviewing AI Output / Issues Found
- Initial dedup key included the source URL, which would miss duplicates with different URLs (and all quotes on a page share one URL). Changed to source + normalized title + normalized author.
- Retries had no backoff or delay; added exponential backoff and a polite request delay (shared http_client.py instead of duplicated fetch functions).
- Prices could show mojibake ("Â£") without explicit UTF-8 decoding; forced utf-8.
- Rating became "3.0" in the CSV because of pandas NaN handling; fixed with nullable Int64.
- scraped_at was set once at the end; now set per record at scrape time.
- Summary report originally lacked rejection reasons and per-source final counts; added, plus rejected/duplicate CSVs.

## Verification
- Ran `pytest tests` (unit tests for cleaning, validation, dedup).
- Ran `python main.py` end to end against the live sites; checked output/final_dataset.csv, summary_report.json and logs/scraper.log, and spot-checked sample records against the websites (expected: 1000 books, 100 quotes).
