import logging
from datetime import datetime, timezone
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from scrapers.http_client import fetch

BASE_URL = "https://quotes.toscrape.com/"


def scrape_quotes():
    records = []
    next_url = BASE_URL
    session = requests.Session()

    while next_url:
        logging.info("Scraping Quotes page: %s", next_url)
        html = fetch(next_url, session)

        if not html:
            break

        soup = BeautifulSoup(html, "html.parser")

        for block in soup.select("div.quote"):
            try:
                text_el = block.select_one("span.text")
                author_el = block.select_one("small.author")
                tag_els = block.select("a.tag")

                if not text_el:
                    logging.warning("Quote text missing on %s", next_url)
                    continue

                quote_text = text_el.get_text(" ", strip=True)
                author = author_el.get_text(" ", strip=True) if author_el else None
                tags = ", ".join(tag.get_text(" ", strip=True) for tag in tag_els)

                records.append({
                    "source": "Quotes to Scrape",
                    "source_url": next_url,
                    "name_or_title": quote_text,
                    "category": None,
                    "price": None,
                    "rating": None,
                    "author": author,
                    "tags": tags or None,
                    "description": None,
                    "availability": None,
                    "scraped_at": datetime.now(timezone.utc).isoformat(),
                })
            except Exception as exc:
                logging.exception("Failed to parse a quote on %s: %s", next_url, exc)

        next_link = soup.select_one("li.next a")
        next_url = urljoin(next_url, next_link.get("href")) if next_link else None

    logging.info("Quotes records collected: %d", len(records))
    return records
