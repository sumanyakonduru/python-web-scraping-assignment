import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from scrapers.http_client import fetch

BASE_URL = "https://books.toscrape.com/"


def rating_to_number(classes):
    mapping = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
    for value in classes:
        if value in mapping:
            return mapping[value]
    return None


def scrape_book_details(book_url, session):
    html = fetch(book_url, session)
    if not html:
        return {}

    soup = BeautifulSoup(html, "html.parser")
    details = {}

    product_table = soup.select_one("table.table-striped")
    if product_table:
        for row in product_table.select("tr"):
            cells = row.select("th, td")
            if len(cells) == 2:
                details[cells[0].get_text(" ", strip=True).lower()] = cells[1].get_text(" ", strip=True)

    category = None
    breadcrumb = soup.select("ul.breadcrumb li a")
    if breadcrumb:
        # The category is normally the last category link before the product title.
        category = breadcrumb[-1].get_text(" ", strip=True)

    description = None
    description_heading = soup.find(id="product_description")
    if description_heading:
        next_p = description_heading.find_next("p")
        if next_p:
            description = next_p.get_text(" ", strip=True)

    return {
        "category": category,
        "description": description,
    }


def scrape_books():
    records = []
    next_url = BASE_URL
    session = requests.Session()

    while next_url:
        logging.info("Scraping Books page: %s", next_url)
        html = fetch(next_url, session)

        if not html:
            # Do not let one failed page crash the complete pipeline.
            break

        soup = BeautifulSoup(html, "html.parser")

        articles = soup.select("article.product_pod")
        detail_urls = []
        for article in articles:
            link = article.select_one("h3 a")
            detail_urls.append(urljoin(next_url, link.get("href")) if link and link.get("href") else None)
        with ThreadPoolExecutor(max_workers=5) as pool:
            details_list = list(pool.map(
                lambda u: scrape_book_details(u, session) if u else {}, detail_urls))

        for article, details in zip(articles, details_list):
            try:
                title_link = article.select_one("h3 a")
                price_el = article.select_one(".price_color")
                availability_el = article.select_one(".availability")
                rating_el = article.select_one("p.star-rating")

                if not title_link:
                    logging.warning("Book title link missing on %s", next_url)
                    continue

                relative_url = title_link.get("href")
                book_url = urljoin(next_url, relative_url)

                records.append({
                    "source": "Books to Scrape",
                    "source_url": book_url,
                    "name_or_title": title_link.get("title", "").strip(),
                    "category": details.get("category"),
                    "price": price_el.get_text(" ", strip=True) if price_el else None,
                    "rating": rating_to_number(rating_el.get("class", [])) if rating_el else None,
                    "author": None,
                    "tags": None,
                    "description": details.get("description"),
                    "availability": availability_el.get_text(" ", strip=True) if availability_el else None,
                    "scraped_at": datetime.now(timezone.utc).isoformat(),
                })
            except Exception as exc:
                logging.exception("Failed to parse a book on %s: %s", next_url, exc)

        next_link = soup.select_one("li.next a")
        next_url = urljoin(next_url, next_link.get("href")) if next_link else None

    logging.info("Books records collected: %d", len(records))
    return records
