import logging
import time

import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; ScrapingAssignment/1.0)"}
REQUEST_DELAY = 0.1  # polite delay between requests (seconds)


def fetch(url, session, retries=3, timeout=10, backoff=1.0):
    """GET a URL with retries and exponential backoff. Returns HTML text or None."""
    for attempt in range(1, retries + 1):
        try:
            time.sleep(REQUEST_DELAY)
            response = session.get(url, headers=HEADERS, timeout=timeout)
            response.raise_for_status()
            response.encoding = "utf-8"  # avoids "Â£" mojibake on prices
            return response.text
        except requests.RequestException as exc:
            logging.warning("Request failed (%s/%s) %s: %s", attempt, retries, url, exc)
            if attempt < retries:
                time.sleep(backoff * 2 ** (attempt - 1))
    logging.error("Giving up on URL: %s", url)
    return None
