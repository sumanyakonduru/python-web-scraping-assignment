# Python Web Scraping Interview Assignment

## Overview
This project scrapes data from two public practice websites:

- Books to Scrape
- Quotes to Scrape

The pipeline performs scraping, cleaning, validation, duplicate detection, consolidation, and output generation.

## Python Version
Python 3.10+ recommended.

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

## Pipeline

```text
Books to Scrape ─┐
                 ├─> Scraping ─> Cleaning ─> Validation
Quotes to Scrape ┘                         ↓
                                      Deduplication
                                           ↓
                                      Consolidation
                                           ↓
                                  CSV + JSON summary
```

## Data Model

The standardized dataset contains:

- source
- source_url
- name_or_title
- category
- price
- rating
- author
- tags
- description
- availability
- scraped_at

Fields not applicable to a source are stored as null.

## Pagination

Both scrapers follow the `next` link found on each page until there is no next page.

## Cleaning

The processing layer:
- removes unnecessary whitespace
- converts prices to numeric values
- standardizes ratings to numbers from 1 to 5
- validates URLs
- normalizes missing text values

## Validation

A record is rejected when:
- its source is unknown
- its source URL is missing/invalid
- its title/quote is missing
- its price is invalid
- its rating is outside 1-5

## Deduplication

Duplicates are identified using:

```text
source + normalized name_or_title + normalized author
```

Normalization: Unicode accent stripping, lowercase, punctuation removal, whitespace collapsing. So `"Example Book Title"`, `" Example Book Title "` and `"EXAMPLE BOOK TITLE"` match. The URL is intentionally excluded from the key because quotes share one page URL and the same item can appear under different URLs. The first occurrence is kept; removed duplicates are saved to `output/duplicates_removed.csv` for review.

## Error Handling

HTTP failures are retried up to three times with exponential backoff (1s, 2s) and a 0.1s polite delay between requests. Book detail pages are fetched with 5 parallel workers. If a listing page fails after all retries, that source stops paginating (logged) but the other source still runs. Parsing failures for individual records are logged and do not stop the whole pipeline.

## Outputs

```text
output/final_dataset.csv
output/summary_report.json
output/rejected_records.csv
output/duplicates_removed.csv
logs/scraper.log
```

## Assumptions

- The supplied practice websites remain publicly accessible.
- Their HTML structure remains compatible with the selectors used.
- A missing source-specific field is represented as null rather than invented.

## Known Limitations

The scraper is designed for this take-home practice assignment rather than a large production environment. A production implementation could add stronger retry/backoff policies, rate limiting, persistent checkpoints, configuration management, and monitoring.


## Tests

```bash
pytest tests
```

## AI Usage Summary

See AI_USAGE.md.
