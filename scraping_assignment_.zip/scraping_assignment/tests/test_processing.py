import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from processing.cleaning import clean_price, clean_text
from processing.validation import validate_record
from processing.deduplication import deduplicate_records


def test_clean_text():
    assert clean_text("  Hello   World  ") == "Hello World"


def test_clean_price():
    assert clean_price("£51.77") == 51.77


def test_validation():
    record = {
        "source": "Books to Scrape",
        "source_url": "https://books.toscrape.com/catalogue/test/index.html",
        "name_or_title": "Test Book",
        "price": 10.5,
        "rating": 4,
    }
    ok, reason = validate_record(record)
    assert ok is True
    assert reason is None


def test_deduplication():
    records = [
        {
            "source": "Books to Scrape",
            "source_url": "https://example.com/a",
            "name_or_title": " Example Book "
        },
        {
            "source": "books to scrape",
            "source_url": "https://example.com/a",
            "name_or_title": "example book"
        },
    ]

    unique, duplicates = deduplicate_records(records)

    assert len(unique) == 1
    assert len(duplicates) == 1


def test_dedup_case_whitespace_punctuation():
    base = {"source": "Quotes to Scrape", "author": "A. Einstein"}
    records = [
        {**base, "source_url": "https://quotes.toscrape.com/", "name_or_title": "Example   Quote!"},
        {**base, "source_url": "https://quotes.toscrape.com/page/2/", "name_or_title": " EXAMPLE QUOTE "},
    ]
    unique, duplicates = deduplicate_records(records)
    assert len(unique) == 1 and len(duplicates) == 1
